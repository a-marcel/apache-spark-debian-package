This directory contains build components not included by default in Spark's build.
